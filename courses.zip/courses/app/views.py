from django.shortcuts import render, redirect
from django.contrib.auth.models import User, auth
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from .models import Students,Courses,studentsReg
from django.db.models import Q

# Create your views here.
def signup(request):

    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        password2 = request.POST['password2']

        if password == password2:
            if User.objects.filter(email=email).exists():
                messages.info(request, 'Email Taken')
                return redirect('/register')
            elif User.objects.filter(username=username).exists():
                messages.info(request, 'Username Taken')
                return redirect('/register')
            else:
                user = User.objects.create_user(username=username, email=email, password=password)
                user.save()
                user_login = auth.authenticate(username=username, password=password)
                auth.login(request, user_login)
                user_model = User.objects.get(username=username)
                new_student = Students.objects.create(user=user_model, id=user_model.id)
                new_student.save()
                return redirect('/home')
        else:
            messages.info(request, 'Password Not Matching')
            return redirect('/register')
    else:
        return render(request, 'app/register.html')
    
def signin(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)
            return redirect('/home')
        else:
            messages.info(request, 'Credentials Invalid')
            return redirect('/login')
    else:
        return render(request, 'app/login.html')

@login_required(login_url='/login')
def logout(request):
    auth.logout(request)
    return redirect('/login')

@login_required(login_url='/login')
def search(request):
    courses = Courses.objects.all()
    search_query=''
    if request.method == 'POST':
        search_query = request.POST.get("query")
        courses = Courses.objects.filter(Q(name__icontains=search_query))
    return render(request, 'app/home.html',context={'courses':courses,'search_query':search_query})

@login_required(login_url='/login')
def register_course(request,pk):
    if not Courses.objects.get(code=pk):
       return redirect('/home')
    user = User.objects.get(username=request.user.username)
    student = Students.objects.filter(user=user)[0]
    if not student:
        messages.info(request, 'this user in admin .')
        return redirect('/home')
    course = Courses.objects.filter(code=pk).first()
    if len(studentsReg.objects.filter(course_id=course,student_id=student)) != 0:
        messages.info(request, 'you are registered .')
        return redirect('/home')
    if len(studentsReg.objects.filter(course_id=course)) == course.capacity:
        messages.info(request, 'Full Course .')
        return redirect('/home')
    schedule_new_course = Courses.objects.filter(code=pk)[0].schedule_id.start_time
    for c in studentsReg.objects.filter(student_id = student):
        if c.course_id.schedule_id.start_time == schedule_new_course:
            messages.info(request, 'conflict with another course .')
            return redirect('/home')
    studentsReg.objects.create(course_id=course,student_id=student)
    studentsReg.save()
    return redirect('/home')

@login_required(login_url='/login')
def course(request,pk):
    course = Courses.objects.filter(code=pk).first()
    student = Students.objects.filter(user=request.user).first()
    regestered = False
    course_student = len(studentsReg.objects.filter(course_id=course))
    if len(studentsReg.objects.filter(course_id=course,student_id=student)) != 0:
        regestered = True
    if regestered == True:
        messages.info(request, 'you are registered .')
    return render(request,'app/course.html',{'course':course,'prerequieits':course.prerequisites.all(),'students':course_student})

@login_required(login_url='/login')
def myCourses(request):
    my_schedule = studentsReg.objects.filter(student_id=Students.objects.filter(user=request.user)[0])
    courses=[]
    for my in my_schedule:
        courses.append(my.course_id)
    return render(request,'app/mycourses.html',{'courses':courses})
    